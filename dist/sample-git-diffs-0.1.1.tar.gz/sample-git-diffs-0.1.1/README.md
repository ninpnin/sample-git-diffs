# sample-git-diffs

```
Sample git diffs uniformly wrt. number of changes per file. The output is formatted as a .diff file.

optional arguments:
  -h, --help            show this help message and exit
  --n N                 Total number of diffs to be sampled
  --diffstat DIFFSTAT   Custom git diff command for the sampling probabilities
  --diffcommand DIFFCOMMAND
                        Custom git diff command for the actual diff
```
